

// example


function getGPA(){
    var name=prompt("Enter the name")
    var grade101= Number (prompt("Enter the 101 grade"))
    var grade102= Number (prompt("Enter 102 grade"))


    var GPA= (grade101+grade102)/2

    document.getElementById("studentList").innerHTML=`<li> name: ${name} ${gpa}</li>`
}