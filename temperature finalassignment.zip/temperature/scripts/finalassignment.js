document.addEventListener("DOMContentLoaded", function() {
    // Add event listener to the button
    var startButton = document.getElementById("startButton");
    if (startButton) {
        startButton.addEventListener("click", function() {
            var startTemperature = parseFloat(prompt("Enter the starting temperature:"));
            var endTemperature = parseFloat(prompt("Enter the ending temperature:"));
            var scale = prompt("Enter the scale (C for Celsius, F for Fahrenheit):");

            if (!isNaN(startTemperature) && !isNaN(endTemperature) && (scale === "C" || scale === "F")) {
                convertTemperatureRange(startTemperature, endTemperature, scale);
            } else {
                alert("Invalid input. Please enter valid temperatures and scale.");
            }
        });
    } else {
        console.error("Element with id 'startButton' not found.");
    }

    // Define the convertTemperatureRange function
    function convertTemperatureRange(startValue, endValue, scale) {
        var message = document.getElementById("message");
        if (message) {
            message.innerHTML = ""; // Clear previous messages
            message.style.display = "block";

            for (let temp = startValue; temp <= endValue; temp++) {
                if (scale === "C") {
                    let fahrenheit = (temp * 9 / 5) + 32;
                    message.innerHTML += temp + "°C is equal to " + fahrenheit.toFixed(2) + "°F<br>";
                } else if (scale === "F") {
                    let celsius = (temp - 32) * 5 / 9;
                    message.innerHTML += temp + "°F is equal to " + celsius.toFixed(2) + "°C<br>";
                }
            }
        } else {
            console.error("Element with id 'message' not found.");
        }
    }
});
