// Function to convert temperature between Celsius and Fahrenheit
function convertTemperature() {
    // Get temperature and scale from input fields
    let temperature = parseFloat(document.getElementById("temperatureInput").value);
    let scale = document.getElementById("scaleInput").value.toUpperCase(); // Convert to uppercase for case insensitivity
    
    // Check if temperature and scale are valid
    if (isNaN(temperature) || (scale !== "C" && scale !== "F")) {
        document.getElementById("resultOutput").value = "Invalid input. Please enter a valid temperature and scale (C or F).";
        return;
    }

    // Convert temperature
    let convertedTemperature;
    if (scale === "C") {
        // Convert Celsius to Fahrenheit
        convertedTemperature = (temperature * 9/5) + 32;
    } else if (scale === "F") {
        // Convert Fahrenheit to Celsius
        convertedTemperature = (temperature - 32) * 5/9;
    }

    // Display the converted temperature in the resultOutput input field
    document.getElementById("resultOutput").value = `Temperature: ${temperature} ${scale} = ${convertedTemperature.toFixed(2)} ${scale === "C" ? "Fahrenheit" : "Celsius"}`;
}