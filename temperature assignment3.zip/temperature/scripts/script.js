

// Ask the user to enter the first number
let firstNumber = parseFloat(prompt("Enter the first number:"));

// Ask the user to enter the second number
let secondNumber = parseFloat(prompt("Enter the second number:"));

// Present a menu allowing the user to select the operation
let operation = prompt(`Select the operation:
1. Addition
2. Subtraction
3. Multiplication
4. Division
Enter the number corresponding to the desired operation:`);

// Perform the selected operation and display the result
let result;
if (operation === "1") {
    result = firstNumber + secondNumber;
} else if (operation === "2") {
    result = firstNumber - secondNumber;
} else if (operation === "3") {
    result = firstNumber * secondNumber;
} else if (operation === "4") {
    if (secondNumber === 0) {
        console.log("Error: Cannot divide by zero.");
    } else {
        result = firstNumber / secondNumber;
    }
} else {
    console.log("Error: Invalid operation.");
}

// Display the result in the console
if (result !== undefined) {
    console.log("Result:", result);
}