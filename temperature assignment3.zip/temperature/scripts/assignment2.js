function convertTemperature() {
    // Get the temperature in Celsius from the user
    let temperatureInCelsius = parseFloat(prompt("Enter the temperature in Celsius:"));

    // Convert Celsius to Fahrenheit using the formula
    let temperatureInFahrenheit = (temperatureInCelsius * 9/5) + 32;

    // Display the converted temperature in the console
    console.log(`Temperature in Fahrenheit: ${temperatureInFahrenheit}`);
}